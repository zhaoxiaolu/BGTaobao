//
//  BGGoodsDetailController.h
//  BGTaobao
//
//  Created by huangzhibiao on 16/2/22.
//  Copyright © 2016年 haiwang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BGGoodsDetailController : UIViewController

@end
